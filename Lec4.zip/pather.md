Проект использует зависимости Cgo - 2 пути решения.
Перепрописываем пути до gcc (компилятора С) 
Дополняем утилитой, разрешающей пакетам Go( использующим C) создавать пакеты

# On Ubuntu/MacOs
sudo apt-get install build-essential

# On Windows
http://tdm-gcc.tdragon.net/download